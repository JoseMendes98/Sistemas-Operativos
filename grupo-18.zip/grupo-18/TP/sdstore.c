#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>


// aqui vamos receber e mandar os pedidos para o servidor
// atraves de um pipe com nome(cliserv)
// se for selecionado o status mandamos o pedido ao servidor
//para saber com as transformaçoes q estam a ser executadas
//e tambem acedemos a quantidade de transormacoes q estao a
// ser executadas em comparaçao com o limite das mesmas
// que estam disponiveis no ficheiro config.txt

//guardar pids de pedido e pid de execuçao, para puder retornar a informaçao correta ao cliente correto
//quando estam todos ocupados transfermoaçoes, duvidas
//cada cliente cria o seu fifo, para puder receber informaçao so de si mesmo
//o cliente cria o seu fifo de resposta



void clear(char* line, int nbytes) {
    int i = 0;
    while(i<1024){
        line[i] = '\0';
        i++;
    }
}

int main(int argc,char *argv[]) {
    int fd1;
    int fd2;


    if (argc == 1) {
        write(1, "./sdstore status\n", 17);
        write(1,
              "./sdstore proc-file priority input-filename output-filename transformation-id-1 transformation-id-2 ...\n",
              105);

    } else {
        mkfifo("clisrv", 0666);



        if (fork() == 0) {

            int pid;

            char *resp = malloc(sizeof(1024));

            if (strcmp(argv[1], "status") == 0) {
                pid = getpid();

                char * fifo = malloc(sizeof(20));
                char * cmd = malloc(sizeof(20));
                sprintf(fifo,"%d",pid);
                strcat(cmd,"status ");
                strcat(cmd,fifo);
                //mkfifo(fifo, 0666);
                int n;
                fd1 = open("clisrv", O_WRONLY);
                if (fd1 == -1) {
                    perror("status error");
                }
                mkfifo(fifo, 0666);
                write(fd1, cmd, 12);
                close(fd1);

                fd2 = open(fifo, O_RDONLY);
                while((n = read(fd2,resp,1024)) > 0) {
                    write(1,resp,n);
                }

                clear(resp,1024);
                close(fd2);


            } else if (strcmp(argv[1], "proc-file") == 0) {
                write(1,"PENDING",7);
                pid = getpid();
                char * fifo = malloc(sizeof(20));
                sprintf(fifo,"%d",pid);
                //char *resp = (char *) malloc(sizeof(1024));
                int n;
                fd1 = open("clisrv", O_WRONLY);
                //write(1, "pending\n", 7);
                char *buf =malloc(sizeof (1024));
                for (int i = 1; i < argc; i++) {
                    strcat(buf, argv[i]);
                    strcat(buf, " ");

                }

                strcat(buf,fifo);
                //mkfifo(fifo, 0666);
                write(fd1, buf, strlen(buf));
                clear(buf,1024);
                close(fd1);
                //fd2 = open(fifo, O_RDONLY);
                //n = read(fd2, resp, 1024);
                //write(1, resp, n);
                //close(fd2);

            }
        }
    }
}

