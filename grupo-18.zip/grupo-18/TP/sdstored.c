#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
//#include "servidor.h"

//aqui vamos ter 3 processos, o primeiro e utilizado para printar
// quaiquer debugs necessarios durante o funcinamneto do programa
// o segundo processo vai estar a ler permanentemente informaçao
// recebida do clientes, apos receber cria um processo filho que vai
// tratar dessa tarefa, enquanto o processo pai vai estar a ouvir
//do pipe cliserv mais informaçoes (pedidos, status)
//ao criamos varios processos filhos, cada um esa a tratar do pedido
//realiazado por qualquer cliente

void clear(char* line,int nbytes) {
    int i = 0;
    while(i<1024){
        line[i] = '\0';
        i++;
    }
}


int exectarefas(char *in,char *out,int quantas,char *transf[quantas]) {
    int ret=2;
    int fdin = open(in,O_RDONLY);
    int fdout= open(out,O_WRONLY | O_CREAT, 0666);

    if(quantas==1){

        if((fork())==0){

            dup2(fdin,0);
            dup2(fdout,1);
            execlp(transf[0], transf[0],NULL);
            _exit(1);
        }

    }else{

        int j = 0;
        int pid;
        int pipe_fdd[quantas - 1][2];
        //TAREFA COM PIPES
        for (int i = 0; i < quantas; i++) {
            //PRIMEIRO COMANDO
            if (i == 0) {


                if (pipe(pipe_fdd[i]) < 0) {
                    perror("pipe");
                    exit(1);
                }
                if ((pid = fork()) == 0) {
                    dup2(fdin, 0);
                    close(pipe_fdd[i][0]);
                    dup2(pipe_fdd[i][1], 1);
                    close(pipe_fdd[i][1]);
                    execlp(transf[j], transf[j], NULL);
                    _exit(1);
                }
                close(pipe_fdd[i][1]);
            }
                //ULTIMO COMANDO
            else if (i == quantas - 1) {
                close(pipe_fdd[i][1]);
                j++;
                if ((pid = fork()) == 0) {
                    dup2(pipe_fdd[i - 1][0], 0);
                    close(pipe_fdd[i - 1][0]);
                    dup2(fdout, 1);
                    execlp(transf[j], transf[j], NULL);
                    _exit(2);
                }
                close(pipe_fdd[i - 1][0]);
            }
                //COMANDO
            else {
                if (pipe(pipe_fdd[i]) < 0) {
                    perror("pipe");
                    exit(1);
                }
                j++;
                if ((pid = fork()) == 0) {
                    dup2(pipe_fdd[i - 1][0], 0);
                    dup2(pipe_fdd[i][1], 1);
                    close(pipe_fdd[i - 1][0]);
                    close(pipe_fdd[i][1]);
                    execlp(transf[j], transf[j], NULL);
                    _exit(1);
                }
                close(pipe_fdd[i - 1][0]);
                close(pipe_fdd[i][1]);
            }
        }
    }
    int status;
    for(int i=0;i<quantas;i++){
        wait(&status);
        if(WIFEXITED(status)==0) ret=2;
    }
    return ret;
}



int main(int argc,char *argv[]) {
    int fd3=open("status",O_CREAT | O_RDWR | O_APPEND,0666);
    int fd;
    int fd2;
    int max = 0;
    char * status = malloc(sizeof(1024));
    if (argc != 3) {
        write(1, "ERRO, Falta de Argumentos", 26);
        return 0;
    }
    write(1, "Bem Vindo\n", 10);
    //leitura do config para as variaveis
    int maxinst[7];
    int nop, bcom, bdecom, gcom, gdecom, encr, decr;
    char *token;
    int fd_conf = open(argv[1], O_RDONLY);
    char buffer[1024];
    char buffer1[2000];
    int r;
    while ((r = read(fd_conf, buffer, 200)) > 0) {
        int i = 0;
        int t;
        char *guarda = strdup(buffer);
        for (int j = 1;; j++) {
            token = strsep(&guarda, " ");
            if (token == NULL)
                break;
            if (isdigit(*token) != 0) {
                t = atoi(token);
                maxinst[i] = t;
                i++;
                max += t;
            }

        }
    }
    //terminaçao do config
    char comando[max+3][20];
    while (1) {
        fd = open("clisrv", O_RDONLY);
        int p;
        int a;
        int z=0;
        while ((p = read(fd, buffer1, 1024)) > 0) {
            //ponderar criar filho
            if (fork() == 0) {
                if (buffer1[0] == 's') {
                    char *boffer= (char *) malloc(sizeof(100)) ;
                    char * fifo = malloc(sizeof(20));
                    char *guarda1 = strdup(buffer1);
                    for (int j = 0;; j++) {
                        token = strsep(&guarda1, " ");
                        if (token == NULL)
                            break;
                        strcpy(comando[j], token);
                    }
                    strcat(fifo,comando[1]);
                    int ler;
                    fd2=open(fifo,O_WRONLY);
                    while((ler=read(fd3,boffer,1024))>0){
                        write(fd2,boffer,ler);
                    }
                    close(fd2);
                    lseek(fd3,0,SEEK_SET);
                }

                    close(fd2);

                } else if (buffer1[0] == 'p') {
                    write(1,"\n",1);
                    int quantas = 0;
                    char *guarda1 = strdup(buffer1);
                    write(fd3,guarda1, strlen(guarda1));
                    write(fd3,"\n",1);
                    for (int j = 0;; j++) {
                        token = strsep(&guarda1, " ");
                        if (token == NULL)
                            break;
                        strcpy(comando[j], token);
                        quantas++;
                    }
                    char *in = strdup(comando[1]);
                    char *out = strdup(comando[2]);
                    z = quantas - 4;
                    char *transf[z];
                    //falta o fifo
                    int i = 3;
                    for (; i < quantas - 1; i++) {
                        transf[i - 3] = malloc(strlen(comando[i]) + 1);
                        strcpy(transf[i - 3], comando[i]);
                    }
                    char *fifo = malloc(sizeof(25));
                    strcat(fifo, comando[quantas - 1]);
                    transf[i] = NULL;
                    quantas -= 4;

                    int res = exectarefas(in, out, quantas, transf);

                    write(1,&res,sizeof (res));
                    if (res == 2) {
                        int fd1 = open(fifo, O_WRONLY);
                        strcat(fifo," concluido");
                        write(fd3,"ola\n",3);
                        write(fd3,fifo, strlen(fifo));
                        write(fd1, "concluido", 9);
                        close(fd3);
                        close(fd1);
                        }
                    }
                }
                clear(buffer1, 1024);
            }
        }


