#ifndef TP_EXEC_H
#define TP_EXEC_H

int exectarefas(char *in,char *out,int quantas,char *transf[quantas]);
void clear(char* line,int nbytes);

#endif //TP_EXEC_H
